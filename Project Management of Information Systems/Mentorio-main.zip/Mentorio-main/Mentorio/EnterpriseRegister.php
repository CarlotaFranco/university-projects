<?php
$db = new mysqli("localhost", "root", "", "mentorio");

$code = $_POST["code"];
$username = $_POST["username"];
$password = $_POST["password"];

$user_rows = $db -> query("select * from users where code = '$code'");

if ($user_rows -> num_rows == 1) {
    header("Location: Register.html");
    exit;
} else {
    $db -> query("insert into enterprise (code, username, password) values ('$code', '$username', '$password')");
    $db -> query("insert into users (type, username, password) values ('enterprise', '$username', '$password')");
    header("Location: Login.html");
    exit;
} 
