<?php
    session_start();
    $db = new mysqli("localhost", "root", "", "mentorio");

    if(empty($_SESSION))
{
  header("Location: Login.html");
  exit;
}

$name = $_POST["name"];
$domain = $_POST["domain"];

$user_rows = $db -> query("select * from domains where name = '$name'");

if ($user_rows -> num_rows == 1) {
    header("Location: EmailsBackoffice.php");
    exit;
} else {
    $db -> query("insert into domains (name, domain) values ('$name', '$domain')");
    header("Location: Backoffice.php");
    exit;
} 

?>