<?php
    session_start();
    $db = new mysqli("localhost", "root", "", "mentorio");

    if(empty($_SESSION))
{
  header("Location: Login.html");
  exit;
}

$username = $_SESSION["username"];
$type = $_SESSION["type"];
echo"<b>Username:</b> $username <br>";
echo"<b>Type:</b> $type <br>";
?>