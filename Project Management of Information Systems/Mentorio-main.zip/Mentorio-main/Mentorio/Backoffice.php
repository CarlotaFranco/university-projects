<?php
    session_start();
    $db = new mysqli("localhost", "root", "", "mentorio");

    if(empty($_SESSION))
{
  header("Location: Login.html");
  exit;
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/login.css" rel="stylesheet">
    <title>Backoffice</title>
</head>
<body>
    <?php
    $username = $_SESSION["username"];
    echo"<h2>Welcome to the backoffice $username</h2>";
    ?>
    <br>
    <div class="login">
        <div class="submit">
            <a id="submit" href="EmailsBackoffice.php">
                Insert Institutional Emails
            </a>
        </div>
        <br>
        <div class="submit">
            <a id="submit" href="#">
                Verify Enterprises
            </a>
        </div>
    </div>
</body>
</html>