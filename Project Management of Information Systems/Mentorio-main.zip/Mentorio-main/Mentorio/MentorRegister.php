<?php
$db = new mysqli("localhost", "root", "", "mentorio");

$name = $_POST["name"];
$email = $_POST["email"];
$username = $_POST["username"];
$password = $_POST["password"];
$workplace = $_POST["workplace"];

$user_rows = $db -> query("select * from users where username = '$username'");

if ($user_rows -> num_rows == 1) {
    header("Location: Register.html");
    exit;
} else {
    $db -> query("insert into mentor (name, email, username, password, workplace) values ('$name', '$email', '$username', '$password', '$workplace')");
    $db -> query("insert into users (type, username, password) values ('mentor', '$username', '$password')");
    header("Location: Login.html");
    exit;
} 
