<?php
$db = new mysqli("localhost", "root", "", "mentorio");

$name = $_POST["name"];
$username = $_POST["username"];
$password = $_POST["password"];
$email = $_POST["email"];

$user_rows = $db -> query("select * from users where username = '$username'");

if ($user_rows -> num_rows == 1) {
    header("Location: Register.html");
    exit;
} else {
    $db -> query("insert into mentee (name, email, username, password) values ('$name', '$email', '$username', '$password')");
    $db -> query("insert into users (type, username, password) values ('mentee', '$username', '$password')");
    header("Location: Login.html");
    exit;
} 
