<?php
    session_start();
    $db = new mysqli("localhost", "root", "", "mentorio");

    if(empty($_SESSION))
{
  header("Location: Login.html");
  exit;
}
?>

<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Our Company | Mentorio</title>

    <link rel = "icon" href = "img/logo_1.png" type = "image/x-icon">

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet"> 

    <!-- Custom CSS -->

    <link href="css/info.css" rel="stylesheet">
    <link href="css/landing-page.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">

    <!-- Custom Fonts -->

    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <!-- CSS only -->

</head>

<body>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
             <ul class="nav navbar-nav navbar-left" align="right" >
                <a href="index.html"> <img id = "logo" class="img-responsive" src="img/logo.png" alt=""></a> 
                </ul>
                <ul class="nav navbar-nav navbar-right" >
                    <li>
                        <a href="Backoffice.php">Backoffice</a> <!-- falta mudarmos o link para a página inicial do backoffice, em que ecolhe o que quer fazer-->
                    </li>
                </ul>
            </div>


    <!--WHO WE ARE-->
    <div class="login" align="left">
        <a href="index.html">
        <div id= "home">
            <i class="fa fa-home"></i>
        </div></a>
        <h2>Insert Institutional Emails</h2>
        <form action="InsertDomain.php" method="post">
            <div class="user-box">
                <input type="text" name="name" required>
                <label>Institution</label>
            </div>
            <div class="user-box">
                <input type="text" name="domain" required>
                <label>Institutional domain</label>
            </div>
            <input type='submit' class ='register_fv' value='Insert'></p>
        </form>
    </div> 

<!-- footer -->
    <footer>
        <div class="container" align="center">
            <div class="row">
                <div class="col-lg-12">
                   
                    <p class="copyright text-muted small">Copyright &copy; Mentorio 2022. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

