<?php
session_start();
$db = new mysqli("localhost", "root", "", "mentorio");

$username = $_POST["username"];
$password = $_POST["password"];

$user = $db -> query("select * from users where username = '$username' and password = '$password'");

if ($user -> num_rows == 1){

    $row = $user -> fetch_assoc();

    $type = $row['type'];

    $_SESSION["username"] = $row['username'];
    $_SESSION["type"] = $row['type'];

    if($type == 'admin')
    {
        header("Location: Backoffice.php");
        exit;
    }
    else
    {
        header("Location: Home.php");
        exit;
    }
} else {
    header("Location: Login.html");
    exit;
}